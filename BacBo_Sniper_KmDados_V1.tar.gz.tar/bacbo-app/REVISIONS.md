# Bac Bo App - Histórico de Versões e Melhorias

## Versão Atual: V5.6 Ultra-Sincronizada
**Data:** 2026-07-19
**Status:** Em teste de assertividade e sincronismo.

### Log de Problemas Resolvidos:
1.  **Delay/Pulo de Resultados:** 
    - *Problema:* O jogo real avançava (ex: 3 vermelhos) e o app mostrava menos resultados ou em ordem errada.
    - *Solução:* Implementado sistema de **IDs Únicos**. O app agora compara o "RG" de cada rodada da Evolution. Se um resultado não está no banco de dados local, ele é inserido na posição correta do histórico, impedindo que rodadas sejam "puladas".
2.  **Bug dos Empates (Ties):**
    - *Problema:* Empates seguidos travavam a lógica ou não apareciam no histórico.
    - *Solução:* Mapeamento explícito de `Tie`. Agora o empate aparece no histórico (Bead Road e Tabela), mas a função `noTies()` garante que a análise de tendência ignore o empate para não quebrar sequências de cores (ex: P - T - P conta como sequência de Player).
3.  **Frequência de Atualização:**
    - Ajustado para **1.5 segundos**. Equilíbrio ideal entre velocidade de resposta e estabilidade do servidor.

### Lógica Sniper (IA):
- **Padrão 3-3-1:** Detecta quando uma sequência longa (3+) é quebrada por uma cor oposta e sugere a virada de mão.
- **Força Física (Dados):** Se a diferença entre os dados for >= 5, o app favorece o fluxo. Se for <= 2, sugere alerta de virada técnica.
- **Concordância de Padrões:** O sinal de "ENTRAR" só é ativado quando **4 dos 5 algoritmos** principais (Big Road, Big Eye, Small Road, Cockroach, Dice Analysis) concordam com a mesma direção.

### Pendências/Observações do Usuário:
- Monitorar se o sistema de cache do navegador ainda interfere (resolvido com `Date.now()` no fetch).
- Verificar comportamento em sequências longas de mais de 5 empates (raro, mas testado na lógica).

---
*Este documento serve como memória técnica para futuras edições de código.*
